$(document).ready(function() {
      
	
	$("#fileuploadDiv").hide()
      $('.dropdown-item').on('click', function() {
        var title = $(this).data('title'); // Get the data-title attribute
        $('#menuTitle').html(title); // Update the title in the other div  
		  $("#mainData").show()
      });
	
	 $('.editbutton').on('click', function() {
		  $("#hideOnSelect").hide()
		  $("#fileuploadDiv").show()
      });
});