$(document).ready(function() {
      
	$("#mainData").hide()
	$("#fileuploadDiv").hide()
      $('.dropdown-item').on('click', function() {
        var title = $(this).data('title'); // Get the data-title attribute
        $('#menuTitle').html(title); // Update the title in the other div  
		  $("#initialmsg").hide()
		  $("#mainData").show()
      });
	
	 $('.editbutton').on('click', function() {
       
		  $("#hideOnSelect").hide()
		  $("#fileuploadDiv").show()
      });
});